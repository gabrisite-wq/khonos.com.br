
<header>
        <div class="brand-strip">
            <div class="container">Aratã by Khono's</div>
        </div>
        <div class="container topbar">
            <a href="index.php" class="brand" aria-label="Aratã by Khono's">
                <span class="brand-submark" aria-hidden="true">
                    <img src="src/images/Logotipo%20-%20Varia%C3%A7%C3%B5es/Isotipo%20Arat%C3%A3%20-%20Original.png" alt="" />
                </span>
                <img class="brand-wordmark" src="src/images/Logotipo%20-%20Varia%C3%A7%C3%B5es/Cor%20Original%20-%20PNG.png" alt="Aratã by Khono's" />
            </a>
            <nav>
                <a href="index.php#beneficios">Nossa história</a>
                <a href="index.php#produtos">Objetivo</a>
                <a href="index.php#contato">Contato</a>
            </nav>
        </div>
        <!--
        <nav class="collection-nav" aria-label="Coleções">
            <a href="index.php#produtos">Fitness</a>

            <a href="#produtos">Sleepwear</a>
            <a href="#produtos">Casual</a>

        </nav>
        -->
    </header>
    
