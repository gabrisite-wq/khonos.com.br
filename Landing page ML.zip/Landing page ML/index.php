<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Aratã by Khono's</title>
    <meta name="description" content="Coleções Aratã com acesso direto aos produtos no Mercado Livre." />
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include "header.php" ?>
    <main class="container">
        <section class="hero">
            <div>
                <span class="eyebrow">Aratã by Khono's</span>
                <h1>Peças que acompanham o ritmo brasileiro, do descanso ao dia a dia.</h1>
                <p>Do ritmo da cidade aos dias de sol, as coleções Aratã unem conforto, presença e liberdade para viver o Brasil do seu jeito.</p>
                <div class="hero-actions">
                    <a class="btn btn-primary" href="#produtos">Conhecer coleções</a>
                    <a class="btn btn-secondary" href="#beneficios">A nossa essência</a>
                </div>
                <div class="stats">
                    <div><strong>Conforto</strong><span>para todos os dias</span></div>
                    <div><strong>Leveza</strong><span>em cada escolha</span></div>
                    <div><strong>Estilo</strong><span>que acompanha você</span></div>
                </div>
            </div>
            <div class="hero-card">
                <img class="hero-model" src="src\images\mod-fem\1.png" alt="Modelo vestindo conjunto Aratã" />

            </div>
        </section>
        <section id="beneficios">
            <div class="section-title">
                <h2>A essência Aratã</h2>
                <p>O jeito brasileiro de se vestir: leve, autêntico e versátil.</p>
            </div>
            <div class="benefits-grid">
                <article class="benefit-card">
                    <h3>Bem-estar em primeiro lugar</h3>
                    <p>Modelagens e materiais escolhidos para trazer conforto real para dentro da sua rotina.</p>
                </article>
                <article class="benefit-card">
                    <h3>Versatilidade que fica</h3>
                    <p>Peças fáceis de combinar, transitar e usar do seu jeito, em diferentes momentos.</p>
                </article>
                <article class="benefit-card">
                    <h3>Presença nos detalhes</h3>
                    <p>Uma curadoria com identidade, feita para valorizar quem você é sem excessos.</p>
                </article>
            </div>
        </section>

        <section id="produtos">
            <div class="section-title">
                <h2>Encontre sua coleção</h2>
                <p>Escolhas para acompanhar o seu movimento, o seu descanso e o seu cotidiano.</p>
            </div>
            <div class="products-grid">
                <article class="product-card">
                    <img class="product-visual" src="src/images/mod-masc/4cores.jpeg" alt="Camisetas Aratã Fitness em várias cores" />
                    <h3>Fitness</h3>
                    <p>Liberdade para se movimentar com segurança e conforto, no seu ritmo.</p>
                    <a class="btn btn-primary" href="products.php" target="_blank" rel="noopener noreferrer">Ver coleção</a>
                </article>
                <!--
                <article class="product-card">
                    <img class="product-visual" src="src/images/Feminino/Conjunto%20Roxo%20Escurto.png" alt="Conjunto feminino Aratã" />
                    <h3>Sleepwear</h3>
                    <p>Texturas leves e um caimento acolhedor para seus momentos de pausa.</p>
                    <div class="price">Para descansar bem</div>
                    <a class="btn btn-primary" href="https://www.mercadolivre.com.br/" target="_blank" rel="noopener noreferrer">Ver coleção</a>
                </article>

                <article class="product-card">
                    <img class="product-visual" src="src/images/Modelo%20Masculino%20-%20Site/4.jpeg" alt="Modelo vestindo camiseta Aratã" />
                    <h3>Casual</h3>
                    <p>Essenciais versáteis para construir combinações simples, bonitas e suas.</p>
                    <div class="price">Para viver todos os dias</div>
                    <a class="btn btn-primary" href="https://www.mercadolivre.com.br/" target="_blank" rel="noopener noreferrer">Ver coleção</a>
                </article>
-->
            </div>
        </section>

        <section class="cta" id="contato">
            <h2>Vista a sua melhor versão.</h2>
            <p>Fale com a Aratã e encontre peças que se conectam com o seu dia a dia.</p>
            <a class="btn btn-secondary" href="mailto:contato@empresa.com">Entrar em contato</a>
        </section>
    </main>
    <?php include "footer.php"?>
</body>
</html>