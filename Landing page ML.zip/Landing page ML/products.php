<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Aratã by Khono's</title>
    <meta name="description" content="Coleções Aratã com acesso direto aos produtos no Mercado Livre." />
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <?php include "header.php" ?>

        <section id="produtos">
            <div class="section-title">
                <h2>Encontre sua coleção</h2>
                <p>Escolhas para acompanhar o seu movimento, o seu descanso e o seu cotidiano.</p>
            </div>
            <div class="products-grid-p">
    <!-- Card Masculino -->
    <article class="product-card-p">
        <div class="product-slider">
            <div class="slider-track">
                <img class="product-visual-p active" src="src/images/mod-masc/1.jpeg" alt="Camiseta Aratã Fitness - Cor 1" />
                <img class="product-visual-p" src="src/images/mod-masc/2.jpeg" alt="Camiseta Aratã Fitness - Cor 2" />
                <img class="product-visual-p" src="src/images/mod-masc/3.jpeg" alt="Camiseta Aratã Fitness - Cor 3" />
            </div>
            <button type="button" class="slider-btn prev" onclick="moveSlide(this, -1)">&lt;</button>
            <button type="button" class="slider-btn next" onclick="moveSlide(this, 1)">&gt;</button>
            <div class="slider-dots">
                <span class="dot active" onclick="goToSlide(this, 0)"></span>
                <span class="dot" onclick="goToSlide(this, 1)"></span>
                <span class="dot" onclick="goToSlide(this, 2)"></span>
            </div>
        </div>

        <h3>Camiseta Masculina Aratã Gola Careca</h3>
        <p>Liberdade para se movimentar com segurança e conforto, no seu ritmo.</p>
        <!--<div class="price"></div>-->
        <a class="btn btn-primary" href="https://www.mercadolivre.com.br/camiseta-masculina-arata-gola-careca-malha-mid-fio-40/up/MLBU5269194288" target="_blank" rel="noopener noreferrer">Comprar</a>
    </article>

    <!-- Card Feminino -->
    <article class="product-card-p">
        <div class="product-slider">
            <div class="slider-track">
                <img class="product-visual-p active" src="src/images/mod-fem/mod-1.png" alt="Conjunto feminino Aratã - Cor 1" />
                <img class="product-visual-p" src="src/images/mod-fem/mod-2.png" alt="Conjunto feminino Aratã - Cor 2" />
                <img class="product-visual-p" src="src/images/mod-fem/mod-3.png" alt="Conjunto feminino Aratã - Cor 3" />
            </div>
            <button type="button" class="slider-btn prev" onclick="moveSlide(this, -1)">&lt;</button>
            <button type="button" class="slider-btn next" onclick="moveSlide(this, 1)">&gt;</button>
            <div class="slider-dots">
                <span class="dot active" onclick="goToSlide(this, 0)"></span>
                <span class="dot" onclick="goToSlide(this, 1)"></span>
                <span class="dot" onclick="goToSlide(this, 2)"></span>
            </div>
        </div>

        <h3>Camiseta Careca Feminina Aratã</h3>
        <p>Malha Mid Fio 40</p>
        <!--<div class="price"></div>-->
        <a class="btn btn-primary" href="https://www.mercadolivre.com.br/camiseta-careca-feminina-arata-malha-mid-fio-40/up/MLBU5231967093" target="_blank" rel="noopener noreferrer">Comprar</a>
    </article>
</div>
        </section>

    </main>

    <?php include "footer.php" ?>
</body>

<script>function updateSlider(slider, newIndex) {
    const images = slider.querySelectorAll('.product-visual-p');
    const dots = slider.querySelectorAll('.dot');
    
    if (newIndex >= images.length) newIndex = 0;
    if (newIndex < 0) newIndex = images.length - 1;

    images.forEach(img => img.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    images[newIndex].classList.add('active');
    if (dots[newIndex]) {
        dots[newIndex].classList.add('active');
    }
}

function moveSlide(btn, direction) {
    const slider = btn.closest('.product-slider');
    const images = slider.querySelectorAll('.product-visual-p');
    const currentIndex = Array.from(images).findIndex(img => img.classList.contains('active'));
    updateSlider(slider, currentIndex + direction);
}

function goToSlide(dot, index) {
    const slider = dot.closest('.product-slider');
    updateSlider(slider, index);
}
</script>
</html>