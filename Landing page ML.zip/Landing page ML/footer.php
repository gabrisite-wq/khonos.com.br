<footer>
        <div class="container">Aratã by Khono's. Vista o que faz sentido para você.</div>
</footer>